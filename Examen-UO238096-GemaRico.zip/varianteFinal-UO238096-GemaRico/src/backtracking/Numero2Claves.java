package backtracking;
	import java.util.Arrays;
	import java.util.List;
	

	public class Numero2Claves {

		//Reglas de las claves 
//		estan formadas por 36 caracteres de 0,9 y de a,z
//		el valor absoluto del numero de digitos menos el numero de letras ha de ser<=1 (Math.abs(digitos-letras))
//		forma ordenada las claves posibles de longitud n mas las claves posibles --> n
//		medir tiempos para n
		
		
		private static  int longitud;
		protected static  char[] password;
		private static int contadorPasswords;
		 

		private static  Character [] caracteres = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p',
				'q','r','s','t','u','v','w','x','y','z'};

		private  Character [] digitos = {'0','1','2','3','4','5','6','7','8','9'};
		
		private static Character[]total = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p',
				'q','r','s','t','u','v','w','x','y','z'};


		static List<Character>caracteresList = Arrays.asList(caracteres);
		List<Character>digitosList = Arrays.asList(digitos);
		List<Character>totalList = Arrays.asList(total);


		public static void main(String[] args) {
			longitud = Integer.parseInt(args[0]);
			
			
			
			long t1=System.currentTimeMillis();
			//for(int j=0;j<1;j++){			
				inicializar();//}
			long t2=System.currentTimeMillis();	
			System.out.println ((t2-t1));
				
		 
			System.out.println(contadorPasswords);
		}


		public static  void inicializar() {
			password = new char[longitud];		
			backtracking(0);
			
		}

		public static  void backtracking(int nivel) {

			if(nivel == longitud) 
			{ //cuando llegamos al final comprobamos
				if(validar(password, nivel)) {
						contadorPasswords++;
						//no se muestran para medir tiempos
//						for (int i = 0; i < password.length; i++) {
//							System.out.print(password[i]);
//				}
//				System.out.println();
			}
			} else {
				Character letra;
				
				for (int i = 0;i < total.length; i++) {
					letra = total[i];
					password[nivel] = letra;
					backtracking(nivel + 1);
					
				}
			}
		}
	
			
		
		private static boolean isCaracter(char c) {
			if(caracteresList.contains(c))
				return true;
			return false;
		}	
		
		
		private static boolean validar(char[] pass, int nivel) {
			
			int contadorCaracteres=0;
			int contadorDigitos=0;
			if(nivel==longitud)
				for(int i = 0; i<pass.length; i++)
				{
					if(isCaracter(pass[i]))
						contadorCaracteres++;
					else
						contadorDigitos++;
				}
					
			if(Math.abs(contadorDigitos-contadorCaracteres)<=1)
				return true;
			return false;					
		}	
		
		
		
		

	
	
}
		
		
		
		
