package backtracking;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class GeneradorClave {

	private int totalSize;
	private int totalSizeSimbolo;
	private int numeroRepeticiones;

	private List<String> caracteres;

	private boolean meta;
	private char[] password;

	private Character[] abc = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', '�', 'o', 'p',
			'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	private Character[] NoAbc = { '.', '*', '$', '@', '#', '_', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

	List<Character> abcList = Arrays.asList(abc);
	List<Character> NoAbcList = Arrays.asList(NoAbc);

	public GeneradorClave(int totalSize, int totalSizeSimbolo, int numeroRepeticiones, List<String> caracteres) {

		this.meta = false;
		this.totalSize = totalSize;
		this.totalSizeSimbolo = totalSizeSimbolo;
		this.caracteres = caracteres;
		this.password = new char[totalSize];
		this.numeroRepeticiones = numeroRepeticiones;
//		for (int i = 0; i < numeroRepeticiones; i++) {
//				meta = false;
//				backtracking(0);
//				print();
//		}
	}

	public void algoritmo() {
		for (int i = 0; i < numeroRepeticiones; i++) {
			meta = false;
			backtracking(0);
		}
	}

	private Character[] copiar(Character[] b) {

		Character[] a = new Character[b.length];
		for (int i = 0; i < b.length; i++)
			a[i] = b[i];
		return a;

	}

	/**
	 * Metodo backtracking que genera contrase�as con unas ciertas condiciones
	 * 
	 */

	public void backtracking(int nivel) {

		Random random = new Random();
		if (nivel == totalSize)
			meta = true;
		else {
			Character[] aux;
			if (nivel < totalSize - totalSizeSimbolo) { // es decir, que no corresponde poner un simbolo de final
				aux = copiar((Character[]) abcList.toArray());
			}

			else {
				aux = copiar((Character[]) NoAbcList.toArray());
			}

			do {
				char letra = aux[random.nextInt(aux.length)];
				if (check(password, nivel, letra) == true) {
					password[nivel] = letra;
					backtracking(nivel + 1);

				}
			} while (meta != true);
		}

	}

	/**
	 * Metodo que comprueba si la letra pasada como parametro es una vocal
	 * 
	 */

	private boolean isVocal(char letra) {

		Character[] vocales = { 'a', 'e', 'i', 'o', 'u' };
		List<Character> vocalesList = Arrays.asList(vocales);

		if (vocalesList.contains(letra))
			return true;
		return false;

	}

	/**
	 * Metodo que comprueba si la letra pasada como parametro es una consonante
	 * 
	 */

	private boolean isConsonante(char letra) {

		Character[] consonantes = { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', '�', 'p', 'q', 'r', 's', 't',
				'v', 'w', 'x', 'y', 'z' };
		List<Character> consonantesList = Arrays.asList(consonantes);

		if (consonantesList.contains(letra))
			return true;
		return false;

	}

	/**
	 * Se quieren generar todas las palabras de n caracteres que cumplan las
	 * siguientes condiciones: 1. Solo pueden aparecer dos vocales seguidas si son
	 * diferentes 2. No puede haber ni tres vocales ni tres consonantes seguidas 3.
	 * Existe un conjunto de parejas de consonantes que pueden aparecer seguidas. 4.
	 * Los dos �ltimos caracteres son signos de puntuaci�n o n�meros.
	 **/

	private boolean check(char[] password, int nivel, char letra) {

		if (nivel > 0) {
			// Solo pueden aparecer dos vocales seguidas si son diferentes
			if (isVocal(letra) && letra == password[nivel - 1])
				return false;

			// Existe un conjunto de parejas de consonantes que pueden aparecer seguidas.
			if (isConsonante(letra) && isConsonante(password[nivel - 1])) {
				if (!caracteres.contains(String.valueOf(password[nivel - 1]) + String.valueOf(letra)))
					return false;
			}
		}

		// No puede haber ni tres vocales ni tres consonantes seguidas
		if (nivel > 1) {

			if (isConsonante(letra) && isConsonante(password[nivel - 1]) && isConsonante(password[nivel - 2]))
				return false;

			if (isVocal(letra) && isVocal(password[nivel - 1]) && isVocal(password[nivel - 2]))
				return false;
		}

		return true;

	}

	/**
	 * Metodo que imprime la contrase�a generada
	 * 
	 */

	public void print() {
		System.out.println(String.valueOf(password));
	}

}
