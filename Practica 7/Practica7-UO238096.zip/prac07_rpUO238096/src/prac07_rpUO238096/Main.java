package prac07_rpUO238096;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class Main {

	private static final String FICHERO_PODA = "files/tiempos02.txt";

	static int tama�o = 0;
	private static int[][] costes;
	static boolean [] marca;

	static int[]asig;// ir calculando la asignaci�n
	static int coste;// su coste 

	static int[]asigMejor;// para anotar la mejor
	static int costeMejor;// coste de la mejor

	private static void cargarTareas() {
		String[] linea = null;
		int contador = 0;
		try {
			BufferedReader fichero = new BufferedReader(new FileReader(FICHERO_PODA));
			while (fichero.ready()) {
				linea = fichero.readLine().split("\t");
				if (linea.length == 1) {
					tama�o = Integer.parseInt(linea[0]);
					costes = new int[tama�o][tama�o];
				} else {
					for (int j = 0; j < linea.length; j++) {
						costes[contador][j] = Integer.parseInt(linea[j]);
					}
					contador++;
				}
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}

	public static void main(String[] args) {
		cargarTareas();
		MiNodo minodo = new MiNodo(tama�o, costes);
		RamificaYPoda rp = new RamificaYPoda(minodo);
		rp.ramificaYPoda();
		rp.mostrarTrazaSolucion();
		tiempos();
		

	}
	
	public static void tiempos()
	{
		long t1,t2;

		for (int tam=1;tam<=20;tam++)
		{
			tama�o=tam; 
			costes=new int[tama�o][tama�o];
			darValorCostes();
			MiNodo minodo = new MiNodo(tama�o, costes);
			RamificaYPoda rp = new RamificaYPoda(minodo);			
			t1=System.currentTimeMillis();
			rp.ramificaYPoda(); 
			t2=System.currentTimeMillis();
			System.out.println (tama�o+","+(t2-t1));
		}
	} 


	public static void darValorCostes()
	
	{
		Random r=new Random();
		for (int i=0;i<tama�o;i++)
			for (int j=0;j<tama�o;j++)
			{
				costes[i][j]=r.nextInt(99)+1;
			}
	}

}
