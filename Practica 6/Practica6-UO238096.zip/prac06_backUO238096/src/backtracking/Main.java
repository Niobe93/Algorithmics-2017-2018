package backtracking;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

	private static final String FICHERO_BACKTRACKING = "files/parejas_consonantes.txt";

	private static List<String> caracteres = new ArrayList<String>();

	private static void cargarCaracteres() {
		String linea = "";
		try {
			BufferedReader fichero = new BufferedReader(new FileReader(FICHERO_BACKTRACKING));
			while (fichero.ready()) {
				linea= fichero.readLine();
				caracteres.add(new String(linea));				
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}

	public static void main(String[] args) {
		cargarCaracteres();
		//new GeneradorClave(8,2,1000, caracteres);		
		
		times();
		
	}
	
	public static void times() {
		
		int nVeces=Integer.parseInt("100");
		
		for(int n=3;n<Integer.MAX_VALUE;n*=2)
		{
			GeneradorClave clave =new GeneradorClave(n, 1, 100, caracteres);
			long t1=System.currentTimeMillis();
			for(int j=0;j<nVeces;j++)
			{
				
				clave.algoritmo();
			}
			long t2=System.currentTimeMillis();
			System.out.println (n+","+(t2-t1));
				
	
	}

}
}
