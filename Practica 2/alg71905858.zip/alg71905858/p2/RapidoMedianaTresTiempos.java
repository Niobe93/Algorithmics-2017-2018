package alg71905858.p2;

public class RapidoMedianaTresTiempos

{
	static int []v;

	public static void main (String arg [] )
	{ 
		String opcion=arg[0];
		int nVeces= 1000;
		long t1,t2;

		for (int n=10000;n<1000000000;n*=2)
		{
			v = new int [n] ;

			if (opcion.compareTo("ordenado")==0)
				Vector.ordenDirecto (v);
			
			else if (opcion.compareTo("inverso")==0)
					Vector.ordenInverso (v);
			else
				Vector.aleatorio (v);

			t1 = System.currentTimeMillis();
			for (int repeticiones = 1; repeticiones <= nVeces; repeticiones++) {
				RapidoMedianaTres.rapido (v);
			}
			t2 = System.currentTimeMillis();
			
			System.out.println (n+"\t"+(t2-t1));
		} 
	} 

}