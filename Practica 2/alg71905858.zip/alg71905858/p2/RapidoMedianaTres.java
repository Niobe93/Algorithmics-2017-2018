package alg71905858.p2;

/** Este programa sirve para ordenar n elementos
	con el algoritmo mejor. Es el QUICKSORT
 */
public class RapidoMedianaTres
{
	static int []v;

	public static void main (String arg [] )
	{
		int n= Integer.parseInt (arg[0]);  //tama�o del problema  
		v = new int [n];

		Vector.ordenDirecto (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		rapido(v);
		System.out.println ("VECTOR ORDENADO ES");
		Vector.escribe (v);

		Vector.ordenInverso (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		rapido(v);
		System.out.println ("VECTOR ORDENADO ES");
		Vector.escribe (v);

		Vector.aleatorio (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		rapido(v);
		System.out.println ("VECTOR ORDENADO ES");
		Vector.escribe (v);

	} // fin de main

	/**
	 * Intercambia los elementos de las posiciones i, j en el array a
	 * es O(1)
	 */
	private static void intercambiar (int[] v, int i, int j)
	{
		int t;
		t=v[i];v[i]=v[j];v[j]=t;
	}

	/** Deja el	pivote en una posicion tal que a su izquierda no 
		hay ning�n mayor, ni a la derecha ning�n menor.
		Es un proceso lineal O(n).  
	 */
	private static int particion(int[]v,int iz,int de) 
	{
		int centro = (de + iz) / 2;
	
	if (v[iz] > v[de])
	    intercambiar(v, iz, de);
	if (v[iz] > v[centro])
	    intercambiar(v, iz, centro);
	if (v[centro] > v[de])
	    intercambiar(v, centro, de);
	return centro;
	}

	/**
	 * Ordenaci�n por el m�todo R�pido (Quicksort)
	 * M�todo divide y vencer�s de complejidad estudiada en clase
	 */  
	private static void rapirec (int[] v, int iz, int de) 
	{
		int pivote;
		int i = iz;
		int j = de - 1;
		

	if (iz < de) { 
	    int centro = particion(v, iz, de);
	   
	    if ((de - iz) >= 3) { 
		pivote = v[centro]; 
		intercambiar(v, centro, de); 

		do {
		    while (v[i] <= pivote && i < de)
			i++; 
		    while (v[j] >= pivote && j > iz)
			j--; 
		    if (i < j)
			intercambiar(v, i, j);
		} while (i < j); 

		
		intercambiar(v, i, de);
		rapirec(v, iz, i - 1);
		rapirec(v, i + 1, de);
	    } 
	} 
	}
    
	

	public static void rapido (int[] v) 
	{
		rapirec(v,0,v.length -1);

	}
     
}
