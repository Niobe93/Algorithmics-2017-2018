package alg71905858.p1 ;


/** Este programa utiliza los m�todos est�ticos de la clase Diagonal1.
 * Sirve para medir tiempos incrementando autom�ticamente
 * el tama�o del problema y adem�s seg�n una escala de tiempos determinada
 * por nVeces, que se mete como argumento en ejecuci�n arg[1]
 * Tambi�n se mete como argumento de ejecuci�n arg[0] la operaci�n sobre la que
 * queremos centrar la medici�n de tiempos (opciones 0,1,2 respectivamente)
 */

public class Diagonal2
{
	static int [][]a;

	public static void main (String arg [] )
	{

		int nVeces = Integer.parseInt (arg[1]); 
		int opcion = Integer.parseInt (arg[0]);
		long t1,t2;


		for( int n=3; n<= 100000 ; n*=2) // n se va incrementando *2   
		{
			a = new int[n][n] ;
			if (opcion==0)		// Operaci�n rellenar
			{
				t1=System.currentTimeMillis();

				for (int repeticion=1;repeticion<=nVeces;repeticion++)
				{  	
					Diagonal1.rellena(a);
				}
				t2=System.currentTimeMillis();

				System.out.println ("TAM= "+n+"**"+"T= "+(t2-t1)+"**"+" nVeces = "+ nVeces);   
			} // fin de if

			else if (opcion==1)		// Operaci�n suma1Diagonal
			{
				Diagonal1.rellena (a);
				t1=System.currentTimeMillis();

				for (int repeticion=1;repeticion<=nVeces;repeticion++)
				{  	
					int s=Diagonal1.suma1Diagonal (a);
				}
				t2=System.currentTimeMillis();

				System.out.println ("TAM= "+n+"**"+"T= "+(t2-t1)+"**"+" nVeces = "+ nVeces);   
			} // fin de else if

			else if (opcion==2)		// Operaci�n suma2Diagonal
			{
				Diagonal1.rellena (a);
				t1=System.currentTimeMillis();

				for (int repeticion=1;repeticion<=nVeces;repeticion++)
				{  	
					int s=Diagonal1.suma2Diagonal (a);
				}

				t2=System.currentTimeMillis();

				System.out.println ("TAM= "+n+"**"+"T= "+(t2-t1)+"**"+" nVeces = "+ nVeces);   
			} // fin de else if


			else System.out.println ("OPCION INCORRECTA"); 

		} // fin de for del tama�o de n 

		System.out.println("\nFin de la medici�n de tiempos *****");

	} // fin de main

} // fin de la clase
