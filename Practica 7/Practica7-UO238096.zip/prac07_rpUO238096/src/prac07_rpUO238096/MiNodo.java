package prac07_rpUO238096;

import java.util.ArrayList;

public class MiNodo extends Estado {		
	   
	    private int[][] matrizCostes; //matriz de costes
	    private int numeroTareas; //numero de repartidores == pedidos
		private boolean[] tareasPorAsignar; //Las tareas que tienen que ser asignadas
		private int[] aux; //almacenar las soluciones que vamos haciendo
		
	    public MiNodo(int numeroTareas, int[][] costes) { 
	    	super();
	    	this.numeroTareas = numeroTareas;
	    	this.matrizCostes = costes;  
	    	this.aux = new int[numeroTareas];
	    	this.tareasPorAsignar = new boolean[numeroTareas];
	    	inicializar();
	    	
	 	   
 }
 
	public MiNodo(MiNodo nodoPadre, int i) { 
		super();		
		crearDesdePadre(nodoPadre);
		recorrido(i);
		if (profundidad == numeroTareas-1) 
			ultimaTarea();
		
		
	}
   
    @Override
    public String toString() {
           	
    	String cadena = "----------------------------------------------------------------------------\n";
    	for (int i=0; i<aux.length; i++) {
        	if (aux[i] != -1)
        		cadena+=("Al repartidor " + i + " se le asigna el pedido " + aux[i] +"\n");
        	else
        		cadena+=("Repartidor " + i + " est� libre \n");
        }
    	
    	cadena += ("Valor heur�stico = " + valorHeuristico + "\n");
    	return cadena;
    }
	   
	   
	
	    @Override
	    public int valorInicialPoda() {
	   		int diagonal1 = 0;
	   		int diagonal2 = 0;	   		
	   		for (int i = 0; i < matrizCostes.length; i++)
	   			diagonal1 += matrizCostes[i][i];	   		
	   		for (int i = 0; i < matrizCostes.length; i++)
	   			diagonal2 += matrizCostes[matrizCostes.length-1-i][i];
	   		if(diagonal1 < diagonal2)
	   			return diagonal1;
	   		else 
	   			return diagonal2; 
		}

	    @Override
	    public void calcularValorHeuristico() {
	    	valorHeuristico = 0;			
			
			for (int i = 0; i<profundidad; i++)
				valorHeuristico += matrizCostes[i][aux[i]];
			
			
			for (int j = 0; j<numeroTareas; j++)
				if (!tareasPorAsignar[j])
					valorHeuristico += getMinimo(j);
		}	    
	   
		@Override
		public ArrayList<MiNodo> expandir() {
			ArrayList<MiNodo> exp= new ArrayList<MiNodo>();			
			for (int i=0; i<numeroTareas; i++)
				if (tareasPorAsignar[i]==false) {  
					MiNodo hijo = new MiNodo(this, i); 
					exp.add(hijo);
				}
			return exp;
		}

		@Override
		public boolean solucion() {
			if (profundidad == numeroTareas)
				return true;
			else return false;
		}
		
		private void crearDesdePadre(MiNodo nodoPadre) {			
			idPadre = nodoPadre.getId();
			numeroTareas = nodoPadre.numeroTareas;
			profundidad = nodoPadre.profundidad;
			aux = nodoPadre.aux.clone();
			tareasPorAsignar = nodoPadre.tareasPorAsignar.clone();
			matrizCostes = nodoPadre.matrizCostes.clone();					
		}
		
		private void inicializar() {
			
			for (int i = 0; i < tareasPorAsignar.length; i++)
		 	   	tareasPorAsignar[i] = false; 
			for (int i = 0; i < aux.length; i++)
	 	   		aux[i] = -1; 	 	   	
		}
		
		private int getMinimo(int j) {
			int minValueColumn = Integer.MAX_VALUE;
			for (int i = profundidad; i<numeroTareas; i++)				
				if (matrizCostes[i][j] < minValueColumn)
					minValueColumn = matrizCostes[i][j];
			return minValueColumn;
		}
		
		private void ultimaTarea() {
			int ultima = -1;						
				for (int i = 0; i <numeroTareas;i++) 
					if (!tareasPorAsignar[i])
						 ultima = i;
				
				recorrido(ultima);
			
		}
		
		private void recorrido(int i) {
			tareasPorAsignar[i] = true;		
			aux[profundidad] = i;
			profundidad++;	
			calcularValorHeuristico();
		}
		
}
 
