package alg71905858.p2;

public class SeleccionTiempos
{
	static int []v;

	public static void main (String arg [] )
	{ 
		String opcion=arg[0];
		long t1,t2;
		System.out.println(opcion);

		for (int n=10000;n<1280001;n*=2)
		{
			v = new int [n] ;

			if (opcion.compareTo("ordenado")==0)
				Vector.ordenDirecto (v);
			
			else if (opcion.compareTo("inverso")==0)
				Vector.ordenInverso (v);
			else
				Vector.aleatorio (v);

			t1 = System.currentTimeMillis();
			Seleccion.seleccion (v);
			t2 = System.currentTimeMillis();

			System.out.println(n+"\t"+(t2-t1));

		} 
	} 
}